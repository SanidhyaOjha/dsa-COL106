# You can add any additional function and class you want to implement in this file
class Empty(Exception):
    
    def __init__(self):
        super().__init__("heap is empty")

