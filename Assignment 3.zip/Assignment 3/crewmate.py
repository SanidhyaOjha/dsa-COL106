'''
    Python file to implement the class CrewMate
'''
from heap import Heap
from treasure import Treasure

def comp(t1, t2):
    return (-t1.arrival - t1.size) > (-t2.arrival - t2.size)
    

class CrewMate:
    '''
    Class to implement a crewmate
    '''
    
    def __init__(self):
        '''
        Arguments:
            None
        Returns:
            None
        Description:
            Initializes the crewmate
        '''
        
        # Write your code here
        self.counter = 0
        self.treasury = []
    
    # Add more methods if required
    def add_treas(self, treas):
        
        pass